def bold(text):
    return "**"+str(text)+"**"

def italics(text):
    return "*"+str(text)+"*"

def strikethrough(text):
    return "~~"+str(text)+"~~"

def underline(text):
    return "__"+str(text)+"__"

def box(text):
    return "```"+str(text)+"```"

def inline(text):
    return "`"+str(text)+"`"